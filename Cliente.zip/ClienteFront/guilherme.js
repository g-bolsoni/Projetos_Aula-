//POST
function cadastrar(){
    var dados = new Object()
    dados.nome = document.getElementById("nome").value
    dados.classificacao = document.getElementById("classificacao").value
    dados.genero = document.getElementById("genero").value
    dados.id = document.getElementById("id").value

    // cria um objeto para fazer a requisição
    var request = new XMLHttpRequest()
    // faz a conexão
    request.open('POST', 'http://localhost:8080/api/game', true)
    // processa a resposta
    request.onload = function() {
        if ((request.status >= 200) && (request.status < 400)) {
            console.log('Conexão feita com Sucesso')
        }
        else{
            console.log(`Erro na conexão`)
        }
    }
    request.setRequestHeader("Content-Type", "application/json")
    request.send(JSON.stringify(dados));
    alert('Game adicionado')
    location.reload()
}

//GET
function carregar(){
// vamos criar elementos de marcação dinamicamente
// recupera o elemento root (div)
const app = document.getElementById('root')
  
    // cria uma outra div chamada container - contem os jogos
const container = document.createElement('div')
    // definie o atributo class da div
container.setAttribute('class', 'container')
    // adiciona esta div dentro da div root
app.appendChild(container)

// vamos consumir a API
// cria um objeto para fazer a requisição
var request = new XMLHttpRequest()
    // faz a conexão
request.open('GET', 'http://localhost:8080/api/game', true)
    // processa a resposta
request.onload = function() {
        // obter os dados JSON do servidor
        // this.response contém os dados
        // converto para JSON
        var games = JSON.parse(this.response)
        if ((request.status >= 200) && (request.status < 400)) {
            // sucesso
            const tabela = document.createElement('table')
            tabela.setAttribute('class', 'table table-striped table-dark')
            container.appendChild(tabela)

            const cabecalho = document.createElement('tr')
            tabela.appendChild(cabecalho)
            const cabeca1 = document.createElement('th')
            cabeca1.textContent = 'Nome'
            const cabeca2 = document.createElement('th')
            cabeca2.textContent = 'Gênero'
            const cabeca3 = document.createElement('th')
            cabeca3.textContent = 'Classificação'
            const cabeca4 = document.createElement('th')
            const cabeca5 = document.createElement('th')
            cabecalho.appendChild(cabeca1)
            cabecalho.appendChild(cabeca2)
            cabecalho.appendChild(cabeca3)
            cabecalho.appendChild(cabeca4)
            cabecalho.appendChild(cabeca5)
           
            
            // estrutura de repetição - varre o vetor dados
            games.forEach(game => {
                // cria uma div do tipo card
                const tr = document.createElement('tr')
                tabela.appendChild(tr)

             
                    // cria elemento h1
                const td1 = document.createElement('td')
                    // adiciona texto ao elemento
                td1.textContent = `Jogo: ${game.nome}`
                    // cria elemento h2
                const td2 = document.createElement('td')
                td2.textContent = `Gênero: ${game.genero}`
                    // cria elemento h3
                const td3 = document.createElement('td')
                td3.textContent = `Classificação: ${game.classificacao}`
                //add coluna 4
                const td4 = document.createElement('td')
                //add img coluna 4
                
                const imagemremove = document.createElement('img')
                //define atributo a img
                imagemremove.setAttribute('src', 'remove.png')
                //ação de clicar
                imagemremove.setAttribute('onclick', `remover(${game.id})`)

                td4.appendChild(imagemremove)

                const td5 = document.createElement('td')

                const imagematualiza = document.createElement('img')

                imagematualiza.setAttribute('src', 'atualiza.png')

                imagematualiza.setAttribute('onclick', `atualizar(${JSON.stringify(game)})`)

                td5.appendChild(imagematualiza)

                    // adiciona h1, h2 e h3 no container
                tr.appendChild(td1)
                tr.appendChild(td2)
                tr.appendChild(td3)
                tr.appendChild(td4)
                tr.appendChild(td5)
                
            });
        } else {
            // problema
            // cria um elemento
            const erro = document.createElement('marquee')
                // define o texto do elemento
            erro.textContent = 'Não funcionou'
                // adiciona na página
            app.appendChild(erro)
        }
    }
    // envia a requisição
request.send();
}
//DELETE
function remover(id){
    
    var request = new XMLHttpRequest()
   
    request.open('DELETE', `http://localhost:8080/api/game/${id}`, true)
    
    request.onload = function(){
        
        if ((request.status >= 200) && (request.status < 400)) {
            console.log('Conexão feita com Sucesso')
        }
        else{
            console.log('Erro na conexão')
        }    
    }
    request.send()
    alert('Game deletado')
    location.reload()
}
//PUT
function atualizar(game){
    document.getElementById('id').value = game.id
    document.getElementById("nome").value = game.nome
    document.getElementById("classificacao").value = game.classificacao
    document.getElementById("genero").value = game.genero

}