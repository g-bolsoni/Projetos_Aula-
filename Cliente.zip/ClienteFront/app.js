//GET
function carregar(){


    //vamos criar elementos de marcação dinamicamente
    //recuperar o id root


    const app = document.getElementById('root')
    
        //criar uma outra div chamada containner - contem os jogos 
    const container = document.createElement('div')
        //definir o atributo class da div
    container.setAttribute('class','container')
        //adicionar a div dentro da pag root 
    app.appendChild(container)
    

    //vamos consumir a API
    //cria um obj para fzr a req

    var req = new XMLHttpRequest()

    req.open('GET','http://localhost:8080/cliente',true)

    req.onload = function(){
    // obter os games do servidor (JSON)
    var cliente = JSON.parse(this.response)//resposta em json
    if ((req.status >=200)&& (req.status<400)){
        //sucesso 
      
        //cria uma tabela 
        const table = document.createElement('table')
        table.setAttribute('class',' table table-dark')
        container.appendChild(table)


        //estrutura de repetição - varre o vetor games
        cliente.forEach(cliente => {
            
            //cria uma linha
            const linha = document.createElement('tr')
            table.appendChild(linha)
 
            //cria uma elemento <td>
            const coluna1 = document.createElement('td')
            coluna1.textContent = `${cliente.nome}`

            //cria uma elemento <td2>
            const coluna2 = document.createElement('td')
            coluna2.textContent = `${cliente.email}`

            //cria uma elemento <td3>
            const coluna3 = document.createElement('td')
            coluna3.textContent = `${cliente.dt_nascimento}`
            
            //Cria um elemento <td4>
            const coluna4 = document.createElement('td')
            coluna4.textContent = `${cliente.cpf_cpnj}`

            //Cria um elemento <td5>
            const coluna5 = document.createElement('td')
            coluna5.textContent = `${cliente.nRua}`
            
            //Cria um elemento <td6>
            const coluna6 = document.createElement('td')
            coluna6.textContent = `${cliente.cep}`

            //Cria um elemento <td7> REMOVER

            const coluna7 = document.createElement('td')
            const imagemRemove = document.createElement('img')
            //define os atributo da img
            imagemRemove.setAttribute('src','remove.png')
            //Ação do clique na img
            imagemRemove.setAttribute('onclick',` deletar(${cliente.id})`)
            coluna7.appendChild(imagemRemove)

            //Cria um elemento <td8> ATUALIZAR
            const coluna8 = document.createElement('td')
            const imagemAtualiza = document.createElement('img')
            imagemAtualiza.setAttribute('src', 'atualiza.png')
            imagemAtualiza.setAttribute('onclick',`atualizar()`)
            coluna8.appendChild(imagemAtualiza)



            //add h1 h2 h3 no cartão
            linha.appendChild(coluna1)
            linha.appendChild(coluna2)
            linha.appendChild(coluna3)
            linha.appendChild(coluna4)
            linha.appendChild(coluna5)
            linha.appendChild(coluna6)
            linha.appendChild(coluna7)
            linha.appendChild(coluna8)

        });
    }else{
        //problema
        const erro = document.createElement('marquee')
        erro.textContent = "Não Funcionou"
        app.appendChild(erro)
    }
    }
    //envia o app 
    req.send()
}

//POST
function cadastrar(){
    //obter os dados do usuario 
    var dados = new Object()
        dados.nome = document.getElementById("Nome").value
        dados.email = document.getElementById("Email").value
        dados.dt_nascimento = document.getElementById("Dt_nascimento").value
        dados.cpf_cpnj = document.getElementById("Cpf_cpnj").value
        dados.nRua = document.getElementById("NRua").value
        dados.cep = document.getElementById("Cep").value
        // Dados Esta entrando 
        alert(dados.dt_nascimento)
        alert(dados.cpf_cpnj)
        //OK 

    //vamos consumir a API
    //cria um obj para fzr a req

    var req = new XMLHttpRequest()
    req.open('POST','http://localhost:8080/cliente',true)

    req.onload = function(){
        if ((req.status >=200)&& (req.status<400)){
            console.log('Conexão feita com sucesso')
        }else{
            console.log('Conexão não realizada')
        }
    }
    //Falar q os dados estão indo em json
    req.setRequestHeader("Content-Type","application/json")
    //Envia a req
    req.send(JSON.stringify(dados))
    alert("Cliente inserido com sucessuful")
    location.reload()
}   
 

//DELETE
function deletar(id){
    var req = new XMLHttpRequest()
   
    req.open('DELETE', `http://localhost:8080/cliente/${id}`, true)
    
    req.onload = function(){
        
        if ((req.status >= 200) && (req.status < 400)) {
            console.log('Conexão feita com Sucesso')
        }
        else{
            console.log('Erro na conexão')
        }    
    }
    req.send()
        alert('Cliente deletado')
    location.reload()
}
//PUT
function atualizar(cliente){

    
    document.getElementById("Nome").value = cliente.nome
    document.getElementById("Email").value = cliente.email
    document.getElementById("Dt_nascimento").value = cliente.dt_nascimento
    document.getElementById("Cpf_cpnj").value = cliente.cpf_cpnj

}